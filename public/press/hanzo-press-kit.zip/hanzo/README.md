# Hanzo Press Kit

## Logos
- hanzo-logo.svg (neutral)
- hanzo-logo-light.svg (use on dark backgrounds)
- hanzo-logo-dark.svg (use on light backgrounds)

## Brand Colors
- Primary: #fd4444
- Secondary: #ff6b6b
- Hover: #e03e3e

## Usage Notes
- Maintain clear space around the mark.
- Do not stretch, skew, or apply unapproved effects.
- Use monochrome variants for best contrast.
